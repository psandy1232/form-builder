import React from 'react'
import './App.css'
//import TestApp from './TestApp'
import {Main} from './layouts'
import Store from '../src/store/configureStore'
function App() {
  return (
    <div className="App">
        <Store>
            <Main />
        </Store>
    </div >
  )
}

export default App
