import React from 'react'
import '../App.css'
import FormBuilder from '../components/FormBuilder'

function Main() {
  return (
    <div className="App">
        <FormBuilder />
    </div >
  )
}

export default Main
