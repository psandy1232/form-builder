/* eslint-disable */
export { default as Main  } from "./Main"